import { Sidebar, MobileNav } from "./Sidebar";
import { Bell, Search, Command } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { notifications } from "@/services/data";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const unreadCount = notifications.filter(n => !n.read).length;
  const [readNotifications, setReadNotifications] = useState<string[]>([]);

  const handleMarkAsRead = (id: string) => {
    setReadNotifications([...readNotifications, id]);
  };

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen max-h-screen overflow-hidden">
        <header className="h-16 border-b border-border/50 glass-strong sticky top-0 z-20 flex items-center justify-between px-4 md:px-6 shrink-0">
          <div className="flex items-center gap-3 flex-1">
            <MobileNav />
            <div className="relative hidden md:flex items-center w-full max-w-md">
              <div className="absolute left-3 flex items-center gap-2 text-muted-foreground pointer-events-none">
                <Search className="w-4 h-4" />
              </div>
              <Input 
                placeholder="Buscar..." 
                className="pl-10 pr-16 h-10 bg-muted/30 border-border/50 hover:border-border focus:border-primary/50 focus:bg-muted/50 transition-all rounded-xl"
              />
              <div className="absolute right-2 hidden lg:flex items-center gap-1 text-muted-foreground text-xs bg-muted/50 px-2 py-1 rounded-md">
                <Command className="w-3 h-3" /> K
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-xl h-10 w-10">
                  <Bell className="w-5 h-5" />
                  {(unreadCount > 0) && (
                    <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-primary rounded-full ring-2 ring-background pulse-glow"></span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 glass-strong border-border/50 rounded-xl p-0 overflow-hidden">
                <div className="p-4 border-b border-border/50 flex items-center justify-between">
                  <span className="font-heading font-bold text-sm uppercase tracking-wider">Notificações</span>
                  {unreadCount > 0 && (
                    <Badge className="bg-primary/20 text-primary border-0 text-xs">{unreadCount} novas</Badge>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.map((notif) => (
                    <DropdownMenuItem 
                      key={notif.id} 
                      className={cn(
                        "flex flex-col items-start gap-1.5 p-4 cursor-pointer rounded-none border-b border-border/30 last:border-0 focus:bg-muted/50",
                        !notif.read && !readNotifications.includes(notif.id) ? "bg-primary/5" : ""
                      )}
                      onClick={() => handleMarkAsRead(notif.id)}
                    >
                      <div className="flex items-center justify-between w-full gap-2">
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "w-2 h-2 rounded-full shrink-0",
                            notif.type === "warning" ? "bg-yellow-500" :
                            notif.type === "error" ? "bg-red-500" :
                            notif.type === "success" ? "bg-emerald-500" : "bg-primary"
                          )} />
                          <span className="font-semibold text-sm">{notif.title}</span>
                        </div>
                        <span className="text-[10px] text-muted-foreground shrink-0">{notif.date}</span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2 pl-4">{notif.message}</p>
                    </DropdownMenuItem>
                  ))}
                </div>
                <div className="p-3 border-t border-border/50 bg-muted/20">
                  <Button variant="ghost" className="w-full h-9 text-xs font-medium text-primary hover:bg-primary/10 rounded-lg">
                    Ver todas as notificações
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <div className="hidden md:flex items-center gap-3 pl-3 border-l border-border/50">
              <div className="text-right">
                <p className="text-sm font-semibold leading-tight">Design Lopes</p>
                <p className="text-[11px] text-muted-foreground">Administrador</p>
              </div>
              <Avatar className="h-9 w-9 border-2 border-primary/30 hover:border-primary transition-colors cursor-pointer">
                <AvatarFallback className="bg-gradient-to-br from-primary/20 to-purple-500/20 text-sm font-bold">DL</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          <div className="p-4 md:p-6 lg:p-8 min-h-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
