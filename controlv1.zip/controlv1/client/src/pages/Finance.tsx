import { invoices, expenses } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Download, MoreHorizontal, Wallet, PieChart as PieChartIcon, Activity, Filter, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const cashflowData = [
  { name: 'Jan', income: 4000, expense: 2400 },
  { name: 'Fev', income: 3000, expense: 1398 },
  { name: 'Mar', income: 5000, expense: 2800 },
  { name: 'Abr', income: 4780, expense: 3908 },
  { name: 'Mai', income: 6890, expense: 4800 },
  { name: 'Jun', income: 5390, expense: 3800 },
  { name: 'Jul', income: 7490, expense: 4300 },
];

export default function Finance() {
  const totalIncome = invoices
    .filter(i => i.status === "paid")
    .reduce((acc, curr) => acc + curr.amount, 0);
  
  const totalPending = invoices
    .filter(i => i.status === "pending" || i.status === "overdue")
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
  const balance = totalIncome - totalExpenses;

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Financeiro</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Controle de receitas, despesas e fluxo de caixa.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-8 sm:h-10 text-xs sm:text-sm border-border/50 rounded-xl hidden sm:flex">
            <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Relatório
          </Button>
          <Button size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white shadow-lg shadow-emerald-500/25 border-0 rounded-xl">
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Transação
          </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4"
      >
        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-emerald-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-emerald-500/20 rounded-lg sm:rounded-xl text-emerald-400">
                  <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-emerald-500/15 text-emerald-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> +12%
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Receita</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalIncome.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-blue-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-blue-500/20 rounded-lg sm:rounded-xl text-blue-400">
                  <PieChartIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-blue-500/15 text-blue-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  Pendente
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">A Receber</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalPending.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-red-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-red-500/20 rounded-lg sm:rounded-xl text-red-400">
                  <TrendingDown className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-red-500/15 text-red-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  <ArrowDownRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> -5%
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Despesas</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalExpenses.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-purple-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-purple-500/20 rounded-lg sm:rounded-xl text-purple-400">
                  <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className={cn(
                  "border-0 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5",
                  balance >= 0 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                )}>
                  {balance >= 0 ? <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> : <ArrowDownRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" />}
                  Saldo
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Balanço</p>
              <h3 className={cn("text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5", balance >= 0 ? "text-emerald-400" : "text-red-400")}>
                R$ {balance.toLocaleString('pt-BR')}
              </h3>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div variants={item}>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
          <CardHeader className="pb-2 px-3 sm:px-4 lg:px-6 pt-3 sm:pt-4 lg:pt-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Fluxo de Caixa</CardTitle>
                <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">Receitas vs Despesas</p>
              </div>
              <div className="flex items-center gap-3 sm:gap-4 text-[10px] sm:text-xs">
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-muted-foreground">Receitas</span>
                </div>
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-red-500" />
                  <span className="text-muted-foreground">Despesas</span>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="h-[200px] sm:h-[250px] lg:h-[280px] px-1 sm:px-2 lg:px-4 pb-3 sm:pb-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={cashflowData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `${value/1000}k`} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    borderColor: 'hsl(var(--border))', 
                    borderRadius: '12px',
                    fontSize: '12px'
                  }}
                  formatter={(value: number, name: string) => [`R$ ${value.toLocaleString('pt-BR')}`, name === 'income' ? 'Receitas' : 'Despesas']}
                />
                <Area type="monotone" dataKey="income" stroke="#10b981" fillOpacity={1} fill="url(#colorIncome)" strokeWidth={2} />
                <Area type="monotone" dataKey="expense" stroke="#ef4444" fillOpacity={1} fill="url(#colorExpense)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </motion.div>

      <Tabs defaultValue="invoices" className="w-full">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 sm:gap-3 mb-3 sm:mb-4">
          <TabsList className="bg-muted/30 border border-border/40 rounded-lg sm:rounded-xl p-0.5 sm:p-1 h-auto">
            <TabsTrigger value="invoices" className="rounded-md sm:rounded-lg text-[10px] sm:text-xs font-medium data-[state=active]:bg-background data-[state=active]:shadow-sm px-3 sm:px-4 py-1.5 sm:py-2">Faturas</TabsTrigger>
            <TabsTrigger value="expenses" className="rounded-md sm:rounded-lg text-[10px] sm:text-xs font-medium data-[state=active]:bg-background data-[state=active]:shadow-sm px-3 sm:px-4 py-1.5 sm:py-2">Despesas</TabsTrigger>
          </TabsList>
          <Button variant="outline" size="sm" className="gap-1.5 sm:gap-2 h-8 sm:h-9 border-border/50 rounded-lg sm:rounded-xl text-xs hidden sm:flex">
            <Filter className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Filtros
          </Button>
        </div>

        <TabsContent value="invoices" className="mt-0">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-border/40 bg-muted/20">
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Descrição</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Cliente</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Data</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Valor</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                      <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/30">
                    {invoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-muted/10 transition-colors group">
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 font-semibold text-xs sm:text-sm">{inv.description}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-muted-foreground hidden sm:table-cell text-xs sm:text-sm">Cliente #{inv.clientId}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-muted-foreground hidden lg:table-cell text-xs sm:text-sm">{new Date(inv.date).toLocaleDateString('pt-BR')}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-right font-mono font-bold text-xs sm:text-sm">R$ {inv.amount.toLocaleString('pt-BR')}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5">
                          <Badge variant="outline" className={cn(
                            "text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5",
                            inv.status === "paid" && "bg-emerald-500/15 text-emerald-400",
                            inv.status === "pending" && "bg-amber-500/15 text-amber-400",
                            inv.status === "overdue" && "bg-red-500/15 text-red-400",
                          )}>
                            {inv.status === "paid" ? "Pago" : inv.status === "pending" ? "Pendente" : "Atrasado"}
                          </Badge>
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-right">
                          <Button variant="ghost" size="icon" className="h-7 w-7 sm:h-8 sm:w-8 opacity-0 group-hover:opacity-100 transition-opacity rounded-md sm:rounded-lg">
                            <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenses" className="mt-0">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-border/40 bg-muted/20">
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Descrição</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Categoria</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Data</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Valor</th>
                      <th className="px-2 sm:px-4 lg:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/30">
                    {expenses.map((exp) => (
                      <tr key={exp.id} className="hover:bg-muted/10 transition-colors group">
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 font-semibold text-xs sm:text-sm">{exp.description}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 hidden sm:table-cell">
                          <Badge variant="secondary" className="text-[9px] sm:text-[10px] font-normal bg-muted/50 capitalize">{exp.category}</Badge>
                        </td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-muted-foreground hidden lg:table-cell text-xs sm:text-sm">{new Date(exp.date).toLocaleDateString('pt-BR')}</td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-right font-mono font-bold text-red-400 text-xs sm:text-sm">- R$ {exp.amount.toLocaleString('pt-BR')}</td>
                        <td className="px-2 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 text-right">
                          <Button variant="ghost" size="icon" className="h-7 w-7 sm:h-8 sm:w-8 opacity-0 group-hover:opacity-100 transition-opacity rounded-md sm:rounded-lg">
                            <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
