import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Plus, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { tasks } from "@/services/data";
import { Badge } from "@/components/ui/badge";

const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const currentDate = new Date();
const currentMonth = currentDate.toLocaleString('pt-BR', { month: 'long' });
const currentYear = currentDate.getFullYear();

const generateCalendarDays = () => {
  const daysArray = [];
  for (let i = 0; i < 3; i++) daysArray.push({ day: 28 + i, type: "prev" });
  for (let i = 1; i <= 30; i++) daysArray.push({ day: i, type: "current" });
  for (let i = 1; i <= 9; i++) daysArray.push({ day: i, type: "next" });
  return daysArray;
};

const calendarDays = generateCalendarDays();

export default function Calendar() {
  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Calendário</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Visualize seus prazos e entregas.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-8 sm:h-10 text-xs sm:text-sm border-border/50 rounded-xl gap-1.5 sm:gap-2 hidden sm:flex">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Google_Calendar_icon_%282020%29.svg" className="w-3.5 h-3.5 sm:w-4 sm:h-4" alt="Google" />
            Sincronizar
          </Button>
          <Button size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Evento
          </Button>
        </div>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between py-3 sm:py-4 px-3 sm:px-4 lg:px-6 border-b border-border/40 bg-muted/10">
          <div className="flex items-center gap-2 sm:gap-3 lg:gap-4">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-bold font-heading capitalize">{currentMonth} {currentYear}</h2>
            <div className="flex items-center bg-muted/30 rounded-md sm:rounded-lg p-0.5">
              <Button variant="ghost" size="icon" className="h-6 w-6 sm:h-8 sm:w-8 rounded-md hover:bg-muted/50"><ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" /></Button>
              <Button variant="ghost" size="icon" className="h-6 w-6 sm:h-8 sm:w-8 rounded-md hover:bg-muted/50"><ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" /></Button>
            </div>
          </div>
          <div className="hidden sm:flex gap-0.5 sm:gap-1 bg-muted/30 p-0.5 sm:p-1 rounded-md sm:rounded-lg">
            <Button variant="secondary" size="sm" className="h-7 sm:h-8 px-2 sm:px-3 text-[10px] sm:text-xs font-medium rounded-md">Mês</Button>
            <Button variant="ghost" size="sm" className="h-7 sm:h-8 px-2 sm:px-3 text-[10px] sm:text-xs font-medium rounded-md">Semana</Button>
            <Button variant="ghost" size="sm" className="h-7 sm:h-8 px-2 sm:px-3 text-[10px] sm:text-xs font-medium rounded-md hidden lg:inline-flex">Dia</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="grid grid-cols-7 border-b border-border/40">
            {days.map(day => (
              <div key={day} className="py-2 sm:py-2.5 text-center text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider border-r border-border/30 last:border-r-0">
                <span className="hidden sm:inline">{day}</span>
                <span className="sm:hidden">{day.charAt(0)}</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 auto-rows-fr">
            {calendarDays.map((date, index) => {
              const dayTasks = tasks.filter((_, i) => (i % 30) + 1 === date.day && date.type === "current");
              const isToday = date.day === currentDate.getDate() && date.type === "current";
              
              return (
                <div 
                  key={index} 
                  className={cn(
                    "min-h-[60px] sm:min-h-[80px] lg:min-h-[100px] border-r border-b border-border/30 p-1 sm:p-1.5 lg:p-2 hover:bg-muted/10 transition-colors relative group",
                    date.type !== "current" && "bg-muted/5 text-muted-foreground/40",
                    index % 7 === 6 && "border-r-0"
                  )}
                >
                  <div className="flex items-center justify-between mb-0.5 sm:mb-1">
                    <span className={cn(
                      "text-[10px] sm:text-xs lg:text-sm font-medium w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center rounded-full transition-colors",
                      isToday ? "bg-primary text-primary-foreground font-bold" : ""
                    )}>
                      {date.day}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-4 w-4 sm:h-5 sm:w-5 opacity-0 group-hover:opacity-100 transition-opacity rounded-md hidden sm:flex"
                    >
                      <Plus className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                    </Button>
                  </div>
                  
                  <div className="space-y-0.5 hidden sm:block">
                    {dayTasks.slice(0, 2).map(task => (
                      <div 
                        key={task.id} 
                        className={cn(
                          "text-[9px] sm:text-[10px] px-1 sm:px-1.5 py-0.5 rounded truncate cursor-pointer border-l-2 hover:opacity-80 transition-opacity",
                          task.priority === "high" ? "bg-red-500/10 border-red-500 text-red-400" :
                          task.priority === "medium" ? "bg-amber-500/10 border-amber-500 text-amber-400" :
                          "bg-blue-500/10 border-blue-500 text-blue-400"
                        )}
                      >
                        {task.title}
                      </div>
                    ))}
                    {dayTasks.length > 2 && (
                      <div className="text-[9px] sm:text-[10px] text-muted-foreground px-1 sm:px-1.5">
                        +{dayTasks.length - 2}
                      </div>
                    )}
                  </div>
                  
                  <div className="sm:hidden">
                    {dayTasks.length > 0 && (
                      <div className="flex gap-0.5 mt-0.5">
                        {dayTasks.slice(0, 3).map((task, i) => (
                          <div 
                            key={i}
                            className={cn(
                              "w-1.5 h-1.5 rounded-full",
                              task.priority === "high" ? "bg-red-500" :
                              task.priority === "medium" ? "bg-amber-500" : "bg-blue-500"
                            )}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 pt-3 sm:pt-4">
            <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider">Próximos Eventos</h3>
          </CardHeader>
          <CardContent className="space-y-2 sm:space-y-3 px-3 sm:px-4 pb-3 sm:pb-4">
            {[
              { title: "Reunião com TechFlow", time: "14:00", type: "meeting" },
              { title: "Entrega do Logo", time: "18:00", type: "deadline" },
              { title: "Call de Alinhamento", time: "10:00", type: "meeting" },
            ].map((event, i) => (
              <div key={i} className="flex items-center gap-2 sm:gap-3 p-2 sm:p-2.5 rounded-lg sm:rounded-xl bg-muted/20 hover:bg-muted/30 transition-colors cursor-pointer">
                <div className={cn(
                  "w-0.5 sm:w-1 h-6 sm:h-8 rounded-full",
                  event.type === "meeting" ? "bg-blue-500" : "bg-amber-500"
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm font-medium truncate">{event.title}</p>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">{event.time}</p>
                </div>
                <Badge variant="outline" className={cn(
                  "text-[8px] sm:text-[9px] border-0 shrink-0",
                  event.type === "meeting" ? "bg-blue-500/15 text-blue-400" : "bg-amber-500/15 text-amber-400"
                )}>
                  {event.type === "meeting" ? "Reunião" : "Prazo"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl lg:col-span-2">
          <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 pt-3 sm:pt-4">
            <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider">Esta Semana</h3>
          </CardHeader>
          <CardContent className="px-3 sm:px-4 pb-3 sm:pb-4">
            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map((day, i) => (
                <div key={day} className="text-center">
                  <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase mb-1.5 sm:mb-2">
                    <span className="hidden sm:inline">{day}</span>
                    <span className="sm:hidden">{day.charAt(0)}</span>
                  </p>
                  <div className={cn(
                    "aspect-square rounded-lg sm:rounded-xl flex items-center justify-center text-xs sm:text-sm font-bold transition-colors cursor-pointer",
                    i === 2 ? "bg-primary text-white" : "bg-muted/30 hover:bg-muted/50"
                  )}>
                    {currentDate.getDate() - 2 + i}
                  </div>
                  <div className="mt-1 sm:mt-1.5 space-y-0.5">
                    {i < 3 && <div className="w-full h-0.5 sm:h-1 rounded-full bg-blue-500/50" />}
                    {i === 4 && <div className="w-full h-0.5 sm:h-1 rounded-full bg-amber-500/50" />}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
