import { goals } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Trophy, TrendingUp, Plus, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Goals() {
  const totalGoals = goals.length;
  const completedGoals = goals.filter(g => (g.current / g.target) >= 1).length;
  const avgProgress = Math.round(goals.reduce((acc, g) => acc + Math.min((g.current / g.target) * 100, 100), 0) / goals.length);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Metas</h1>
            <Trophy className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Acompanhe seu progresso e conquiste objetivos.</p>
        </div>
        <Button className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Meta
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
        <Card className="border-border/40 bg-gradient-to-br from-amber-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
          <CardContent className="p-3 sm:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2.5 sm:p-3.5 bg-amber-500/20 rounded-lg sm:rounded-xl text-amber-400">
              <Trophy className="w-5 h-5 sm:w-7 sm:h-7" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Nível Atual</p>
              <h3 className="text-base sm:text-xl font-bold font-heading text-amber-400">Gold Freelancer</h3>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">Top 5% de faturamento</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2 border-border/40 bg-gradient-to-r from-primary/5 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardContent className="p-3 sm:p-5">
            <div className="flex justify-between items-center mb-2 sm:mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg">
                  <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm">Progresso do Mês</h3>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">{completedGoals}/{totalGoals} concluídas</p>
                </div>
              </div>
              <Badge className="bg-primary/15 text-primary border-0 font-bold text-[10px] sm:text-xs">{avgProgress}%</Badge>
            </div>
            <Progress value={avgProgress} className="h-2 sm:h-3 bg-muted/30" />
            <p className="text-[10px] sm:text-xs text-muted-foreground mt-1.5 sm:mt-2">Continue assim! Você está no caminho certo.</p>
          </CardContent>
        </Card>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {goals.map((goal, i) => {
          const progress = Math.min(Math.round((goal.current / goal.target) * 100), 100);
          const isCompleted = progress >= 100;
          
          return (
            <motion.div key={goal.id} variants={item}>
              <Card className={cn(
                "border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-300 card-hover h-full",
                isCompleted && "border-emerald-500/30"
              )}>
                <CardContent className="p-4 sm:p-6 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-3 sm:mb-4">
                    <div className={cn(
                      "p-2 sm:p-2.5 rounded-lg sm:rounded-xl",
                      isCompleted ? "bg-emerald-500/20 text-emerald-400" : "bg-primary/10 text-primary"
                    )}>
                      {isCompleted ? <Trophy className="w-4 h-4 sm:w-5 sm:h-5" /> : <Target className="w-4 h-4 sm:w-5 sm:h-5" />}
                    </div>
                    <Badge variant="outline" className={cn(
                      "text-[9px] sm:text-[10px] font-semibold border-0 px-1.5 sm:px-2 py-0.5",
                      isCompleted 
                        ? "bg-emerald-500/15 text-emerald-400" 
                        : progress >= 75 
                          ? "bg-blue-500/15 text-blue-400"
                          : progress >= 50 
                            ? "bg-amber-500/15 text-amber-400"
                            : "bg-muted text-muted-foreground"
                    )}>
                      {isCompleted ? "Concluída" : `${progress}%`}
                    </Badge>
                  </div>

                  <div className="flex-1">
                    <h3 className="font-bold text-sm sm:text-base font-heading mb-1">{goal.title}</h3>
                    <p className="text-[10px] sm:text-xs text-muted-foreground mb-3 sm:mb-4">{goal.description}</p>
                  </div>

                  <div className="space-y-2 sm:space-y-3">
                    <div className="flex items-center justify-between text-[10px] sm:text-xs">
                      <span className="text-muted-foreground font-medium">{goal.current.toLocaleString('pt-BR')} / {goal.target.toLocaleString('pt-BR')}</span>
                      <span className="font-bold">{goal.unit}</span>
                    </div>
                    <Progress 
                      value={progress} 
                      className={cn("h-1.5 sm:h-2", isCompleted && "bg-emerald-500/20")} 
                    />
                    <div className="flex items-center justify-between text-[9px] sm:text-[10px] text-muted-foreground pt-1 sm:pt-2 border-t border-border/30">
                      <span>Prazo: {new Date(goal.deadline).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}</span>
                      {isCompleted && (
                        <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                          <Zap className="w-2.5 h-2.5 sm:w-3 sm:h-3" /> Meta atingida!
                        </span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </motion.div>
    </div>
  );
}
