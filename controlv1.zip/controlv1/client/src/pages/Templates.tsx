import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Star, ArrowRight, Sparkles, Search, Copy } from "lucide-react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { cn } from "@/lib/utils";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const templates = [
  { id: 1, title: "Proposta Comercial Premium", category: "Propostas", description: "Template completo com apresentação, escopo, cronograma e investimento.", popular: true, downloads: 234 },
  { id: 2, title: "Contrato de Prestação de Serviços", category: "Jurídico", description: "Cláusulas essenciais para proteger seu trabalho e direitos autorais.", popular: true, downloads: 189 },
  { id: 3, title: "Briefing de Identidade Visual", category: "Design", description: "Perguntas estratégicas para extrair a essência da marca do cliente.", popular: false, downloads: 156 },
  { id: 4, title: "Relatório de Performance Mensal", category: "Relatórios", description: "Modelo visual para apresentar resultados e métricas para o cliente.", popular: false, downloads: 98 },
  { id: 5, title: "Checklist de Lançamento de Site", category: "Processos", description: "Lista de verificação para garantir que nada seja esquecido.", popular: false, downloads: 145 },
  { id: 6, title: "Email de Follow-up Comercial", category: "Comunicação", description: "Sequência de emails para converter leads em clientes.", popular: true, downloads: 210 },
];

const categories = ["Todos", "Propostas", "Jurídico", "Design", "Relatórios", "Processos", "Comunicação"];

export default function Templates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todos");

  const filteredTemplates = templates.filter(
    (template) =>
      (selectedCategory === "Todos" || template.category === selectedCategory) &&
      template.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Templates</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Documentos prontos para acelerar seu trabalho.</p>
        </div>
        <Button className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <FileText className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Criar Template
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <Copy className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{templates.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-amber-500/10 rounded-lg sm:rounded-xl text-amber-500">
              <Star className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Populares</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{templates.filter(t => t.popular).length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Downloads</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{templates.reduce((acc, t) => acc + t.downloads, 0)}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar templates..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="overflow-x-auto flex gap-1 sm:gap-1.5 px-2 sm:px-0 hide-scrollbar-mobile">
          {categories.slice(0, 5).map((cat) => (
            <Button 
              key={cat}
              variant={selectedCategory === cat ? "secondary" : "ghost"} 
              size="sm"
              onClick={() => setSelectedCategory(cat)}
              className={cn(
                "h-7 sm:h-8 px-2 sm:px-3 text-[10px] sm:text-xs rounded-lg whitespace-nowrap shrink-0",
                selectedCategory === cat && "bg-primary/10 text-primary"
              )}
            >
              {cat}
            </Button>
          ))}
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {filteredTemplates.map((template) => (
          <motion.div key={template.id} variants={item}>
            <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover h-full flex flex-col">
              <CardContent className="p-4 sm:p-5 flex-1">
                <div className="flex justify-between items-start mb-3 sm:mb-4">
                  <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl">
                    <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  </div>
                  {template.popular && (
                    <Badge className="bg-amber-500/15 text-amber-400 border-0 text-[9px] sm:text-[10px] font-semibold">
                      <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 fill-current" /> Popular
                    </Badge>
                  )}
                </div>

                <Badge variant="outline" className="mb-2 sm:mb-3 text-[9px] sm:text-[10px] font-medium border-border/40 bg-muted/20">
                  {template.category}
                </Badge>

                <h3 className="text-sm sm:text-base font-bold font-heading mb-1 sm:mb-2 group-hover:text-primary transition-colors line-clamp-2">{template.title}</h3>
                <p className="text-[10px] sm:text-xs text-muted-foreground line-clamp-2">{template.description}</p>

                <div className="flex items-center gap-1 sm:gap-1.5 mt-3 sm:mt-4 text-[10px] sm:text-xs text-muted-foreground">
                  <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span>{template.downloads} downloads</span>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/10 p-2 sm:p-3 border-t border-border/30 gap-2">
                <Button variant="outline" className="flex-1 h-8 sm:h-9 text-[10px] sm:text-xs font-medium border-border/50 rounded-lg sm:rounded-xl">
                  <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-1 sm:mr-1.5" /> Baixar
                </Button>
                <Button variant="ghost" className="flex-1 h-8 sm:h-9 text-[10px] sm:text-xs font-medium hover:bg-primary hover:text-white rounded-lg sm:rounded-xl">
                  Usar <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 ml-1 sm:ml-1.5" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
