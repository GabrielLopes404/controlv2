import { useState } from "react";
import { clients } from "@/services/data";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, MoreHorizontal, Mail, Phone, Building, LayoutGrid, Kanban, ArrowRight, Wallet, Star, SlidersHorizontal, Users } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Clients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [view, setView] = useState<"grid" | "pipeline">("grid");

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.company.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRevenue = clients.reduce((acc, c) => acc + c.totalRevenue, 0);
  const activeClients = clients.filter(c => c.status === 'active').length;

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Clientes</h1>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Gerencie sua carteira e relacionamentos.</p>
        </div>
        <Button size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Cliente
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <Users className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{clients.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg sm:rounded-xl text-emerald-500">
              <Star className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Ativos</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{activeClients}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">LTV Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">R$ {totalRevenue.toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-muted/30 p-0.5 sm:p-1 rounded-lg sm:rounded-xl flex items-center gap-0.5 sm:gap-1">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setView("grid")} 
              className={cn("h-7 sm:h-8 px-2 sm:px-3 rounded-md sm:rounded-lg transition-all text-[10px] sm:text-xs font-medium", view === "grid" && "bg-background shadow-sm")}
            >
              <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4 sm:mr-1.5" /> <span className="hidden sm:inline">Grade</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setView("pipeline")} 
              className={cn("h-7 sm:h-8 px-2 sm:px-3 rounded-md sm:rounded-lg transition-all text-[10px] sm:text-xs font-medium", view === "pipeline" && "bg-background shadow-sm")}
            >
              <Kanban className="w-3.5 h-3.5 sm:w-4 sm:h-4 sm:mr-1.5" /> <span className="hidden sm:inline">Pipeline</span>
            </Button>
          </div>
          <Button variant="outline" size="sm" className="h-8 sm:h-9 border-border/50 rounded-lg sm:rounded-xl gap-1.5 text-xs hidden sm:flex">
            <SlidersHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Filtros
          </Button>
        </div>
      </div>

      {view === "grid" ? (
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
        >
          {filteredClients.map((client) => (
            <motion.div key={client.id} variants={item}>
              <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover">
                <div className="h-14 sm:h-20 bg-gradient-to-br from-primary/10 via-purple-500/5 to-blue-500/10 relative">
                  <div className="absolute top-2 sm:top-3 right-2 sm:right-3">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-6 w-6 sm:h-8 sm:w-8 p-0 bg-background/50 backdrop-blur-sm rounded-md sm:rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreHorizontal className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl">
                        <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                        <DropdownMenuItem>Editar</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                <CardContent className="pt-0 relative px-3 sm:px-5 pb-3 sm:pb-5">
                  <div className="flex justify-between items-end -mt-6 sm:-mt-8 mb-3 sm:mb-4">
                    <Avatar className="h-12 w-12 sm:h-16 sm:w-16 border-3 sm:border-4 border-card shadow-lg rounded-lg sm:rounded-xl">
                      <AvatarImage src={client.avatar} alt={client.name} />
                      <AvatarFallback className="text-sm sm:text-lg bg-gradient-to-br from-primary/20 to-purple-500/20 font-heading font-bold rounded-lg sm:rounded-xl">{client.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <Badge variant="outline" className={cn(
                      "text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5",
                      client.status === "active" && "bg-emerald-500/15 text-emerald-400",
                      client.status === "lead" && "bg-blue-500/15 text-blue-400",
                      client.status === "inactive" && "bg-muted text-muted-foreground",
                    )}>
                      {client.status === "active" ? "Ativo" : client.status === "lead" ? "Lead" : "Inativo"}
                    </Badge>
                  </div>

                  <div className="mb-3 sm:mb-4">
                    <h3 className="text-base sm:text-lg font-bold font-heading leading-tight group-hover:text-primary transition-colors">{client.name}</h3>
                    <div className="flex items-center gap-1 sm:gap-1.5 text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1">
                      <Building className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      <span className="truncate">{client.company}</span>
                    </div>
                  </div>

                  <div className="space-y-1.5 sm:space-y-2 mb-3 sm:mb-4">
                    <div className="flex items-center text-xs sm:text-sm text-muted-foreground bg-muted/20 p-2 sm:p-2.5 rounded-lg sm:rounded-xl hover:bg-muted/30 transition-colors">
                      <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2 sm:mr-2.5 text-primary/60 shrink-0" />
                      <span className="truncate text-[11px] sm:text-xs">{client.email}</span>
                    </div>
                    <div className="flex items-center text-xs sm:text-sm text-muted-foreground bg-muted/20 p-2 sm:p-2.5 rounded-lg sm:rounded-xl hover:bg-muted/30 transition-colors">
                      <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2 sm:mr-2.5 text-primary/60 shrink-0" />
                      <span className="text-[11px] sm:text-xs">{client.phone}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-3 sm:pt-4 border-t border-border/40">
                    <div>
                      <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase font-semibold tracking-wider mb-0.5">LTV Total</p>
                      <p className="font-mono font-bold text-xs sm:text-sm flex items-center gap-0.5 sm:gap-1">
                        <span className="text-emerald-400">R$</span> {client.totalRevenue.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase font-semibold tracking-wider mb-0.5">Projetos</p>
                      <p className="font-bold text-xs sm:text-sm">{client.projectsCount}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/10 p-2 sm:p-3 border-t border-border/30">
                  <Button variant="ghost" className="w-full text-[10px] sm:text-xs font-semibold hover:bg-primary hover:text-white transition-all rounded-lg sm:rounded-xl h-8 sm:h-9 group/btn">
                    Ver Perfil <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 ml-1 sm:ml-1.5 group-hover/btn:translate-x-0.5 transition-transform" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pb-4 overflow-x-auto">
          {['Lead', 'Contato', 'Proposta', 'Fechado'].map((stage, idx) => (
            <div key={stage} className="bg-muted/10 rounded-xl sm:rounded-2xl border border-border/40 p-2 sm:p-3 flex flex-col min-w-[260px] sm:min-w-[280px]">
              <div className="flex items-center justify-between mb-3 sm:mb-4 px-1">
                <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-1.5 sm:gap-2">
                  <span className={cn(
                    "w-2 h-2 rounded-full",
                    idx === 0 ? "bg-blue-500" : idx === 1 ? "bg-amber-500" : idx === 2 ? "bg-purple-500" : "bg-emerald-500"
                  )} />
                  {stage}
                </h3>
                <Badge variant="secondary" className="text-[10px] sm:text-xs bg-muted/50 font-medium">{Math.floor(Math.random() * 5) + 1}</Badge>
              </div>
              <div className="space-y-2 sm:space-y-3 flex-1">
                {[1, 2].map((i) => (
                  <Card key={i} className="cursor-grab hover:border-primary/30 shadow-sm rounded-lg sm:rounded-xl border-border/40 bg-card/60">
                    <CardContent className="p-2.5 sm:p-3.5">
                      <div className="flex justify-between mb-1.5 sm:mb-2">
                        <Badge variant="outline" className="text-[9px] sm:text-[10px] border-0 bg-red-500/10 text-red-400">Prioridade</Badge>
                        <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" />
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm mb-0.5 sm:mb-1">Empresa Exemplo {i}</h4>
                      <p className="text-[10px] sm:text-xs text-muted-foreground mb-2 sm:mb-3">R$ 5.000,00</p>
                      <div className="flex items-center gap-2">
                        <Avatar className="w-5 h-5 sm:w-6 sm:h-6">
                          <AvatarFallback className="text-[8px] sm:text-[9px] bg-muted">JD</AvatarFallback>
                        </Avatar>
                        <span className="text-[9px] sm:text-[10px] text-muted-foreground">2 dias atrás</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
