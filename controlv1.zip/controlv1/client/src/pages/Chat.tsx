import { useState } from "react";
import { clients } from "@/services/data";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Phone, Video, MoreVertical, Paperclip, Smile, Search, Sparkles, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

const messages = [
  { id: 1, sender: "client", text: "Olá! Conseguimos adiantar a reunião de amanhã?", time: "09:30", clientId: "1" },
  { id: 2, sender: "me", text: "Bom dia! Claro, qual horário fica bom para você?", time: "09:32", clientId: "1" },
  { id: 3, sender: "client", text: "Pode ser às 14h?", time: "09:35", clientId: "1" },
  { id: 4, sender: "me", text: "Combinado! Te envio o invite agora mesmo.", time: "09:35", clientId: "1" },
  { id: 5, sender: "client", text: "Perfeito, muito obrigado!", time: "09:36", clientId: "1" },
];

export default function Chat() {
  const [selectedClient, setSelectedClient] = useState(clients[0]);
  const [newMessage, setNewMessage] = useState("");
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] sm:h-[calc(100vh-100px)] gap-3 sm:gap-4">
      <div className="flex flex-col gap-0.5 sm:gap-1 shrink-0">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Chat</h1>
          <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
        </div>
        <p className="text-muted-foreground text-xs sm:text-sm">Comunicação direta com seus clientes.</p>
      </div>

      <Card className="flex-1 flex overflow-hidden border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
        <div className={cn(
          "w-full md:w-72 lg:w-80 border-r border-border/40 flex flex-col bg-muted/5",
          showChat ? "hidden md:flex" : "flex"
        )}>
          <div className="p-2 sm:p-3 border-b border-border/40">
            <div className="relative">
              <Search className="absolute left-2.5 sm:left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" />
              <Input placeholder="Buscar..." className="pl-8 sm:pl-9 h-8 sm:h-9 text-xs sm:text-sm bg-muted/30 border-border/40 rounded-lg sm:rounded-xl" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto hide-scrollbar-mobile">
            <div className="flex flex-col">
              {clients.map((client) => (
                <button
                  key={client.id}
                  onClick={() => { setSelectedClient(client); setShowChat(true); }}
                  className={cn(
                    "flex items-center gap-2.5 sm:gap-3 p-3 sm:p-3.5 hover:bg-muted/30 transition-colors text-left border-l-2",
                    selectedClient.id === client.id 
                      ? "bg-primary/5 border-primary" 
                      : "border-transparent hover:border-muted"
                  )}
                >
                  <div className="relative shrink-0">
                    <Avatar className="h-9 w-9 sm:h-10 sm:w-10">
                      <AvatarImage src={client.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-primary/20 to-purple-500/20 text-[10px] sm:text-xs font-bold">{client.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className={cn(
                      "absolute bottom-0 right-0 w-2.5 h-2.5 sm:w-3 sm:h-3 border-2 border-card rounded-full",
                      client.status === "active" ? "bg-emerald-500" : "bg-muted-foreground"
                    )} />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="font-semibold text-xs sm:text-sm truncate">{client.name}</span>
                      <span className="text-[9px] sm:text-[10px] text-muted-foreground shrink-0">09:30</span>
                    </div>
                    <p className="text-[10px] sm:text-xs text-muted-foreground truncate">{client.company}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className={cn(
          "flex-1 flex-col bg-background/50",
          showChat ? "flex" : "hidden md:flex"
        )}>
          <div className="h-14 sm:h-16 border-b border-border/40 flex items-center justify-between px-3 sm:px-5 bg-card/30">
            <div className="flex items-center gap-2 sm:gap-3">
              <Button variant="ghost" size="icon" className="md:hidden h-8 w-8 rounded-lg" onClick={() => setShowChat(false)}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Avatar className="h-8 w-8 sm:h-10 sm:w-10">
                <AvatarImage src={selectedClient.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-primary/20 to-purple-500/20 text-xs sm:text-sm font-bold">{selectedClient.name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-bold text-xs sm:text-sm">{selectedClient.name}</h3>
                <p className="text-[10px] sm:text-xs text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full pulse-glow" /> Online
                </p>
              </div>
            </div>
            <div className="flex items-center gap-0.5 sm:gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-muted/50 hidden sm:flex"><Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-muted/50 hidden sm:flex"><Video className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-muted/50"><MoreVertical className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" /></Button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 sm:p-5 hide-scrollbar-mobile">
            <div className="space-y-3 sm:space-y-4">
              <div className="flex justify-center">
                <Badge variant="outline" className="text-[9px] sm:text-[10px] text-muted-foreground border-border/40 bg-muted/20 rounded-md sm:rounded-lg px-2 sm:px-3">Hoje</Badge>
              </div>
              
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={cn(
                    "flex gap-2 sm:gap-3 max-w-[85%] sm:max-w-[75%]",
                    msg.sender === "me" ? "ml-auto flex-row-reverse" : ""
                  )}
                >
                  <Avatar className="w-6 h-6 sm:w-8 sm:h-8 mt-1 shrink-0">
                    <AvatarFallback className={cn("text-[9px] sm:text-[10px] font-bold", msg.sender === "me" ? "bg-primary text-primary-foreground" : "bg-muted")}>
                      {msg.sender === "me" ? "EU" : selectedClient.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={cn(
                    "p-2.5 sm:p-3 rounded-xl sm:rounded-2xl text-xs sm:text-sm shadow-sm",
                    msg.sender === "me" 
                      ? "bg-gradient-to-br from-primary to-purple-600 text-white rounded-tr-md" 
                      : "bg-muted/50 rounded-tl-md border border-border/40"
                  )}>
                    <p className="leading-relaxed">{msg.text}</p>
                    <span className={cn(
                      "text-[9px] sm:text-[10px] block text-right mt-1 sm:mt-1.5 opacity-70",
                      msg.sender === "me" ? "text-white/70" : "text-muted-foreground"
                    )}>
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 sm:p-4 border-t border-border/40 bg-card/30">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-muted/50 hidden sm:flex"><Paperclip className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" /></Button>
              <Input 
                placeholder="Digite sua mensagem..." 
                className="flex-1 bg-muted/30 border-border/40 focus-visible:ring-primary/30 rounded-lg sm:rounded-xl h-9 sm:h-10 text-xs sm:text-sm"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-muted/50 hidden sm:flex"><Smile className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" /></Button>
              <Button size="icon" className="shrink-0 h-9 w-9 sm:h-10 sm:w-10 bg-gradient-to-br from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 rounded-lg sm:rounded-xl">
                <Send className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
