import { useState } from "react";
import { proposals, clients } from "@/services/data";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, FileText, Send, Download, MoreHorizontal, Calendar, Sparkles, ArrowRight, Check, X } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Proposals() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredProposals = proposals.filter(
    (prop) =>
      prop.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clients.find(c => c.id === prop.clientId)?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "accepted": return { label: "Aceita", color: "bg-emerald-500/15 text-emerald-400", icon: Check };
      case "rejected": return { label: "Rejeitada", color: "bg-red-500/15 text-red-400", icon: X };
      case "sent": return { label: "Enviada", color: "bg-blue-500/15 text-blue-400", icon: Send };
      case "draft": return { label: "Rascunho", color: "bg-muted text-muted-foreground", icon: FileText };
      default: return { label: status, color: "bg-muted text-muted-foreground", icon: FileText };
    }
  };

  const totalValue = proposals.reduce((acc, p) => acc + p.value, 0);
  const acceptedValue = proposals.filter(p => p.status === 'accepted').reduce((acc, p) => acc + p.value, 0);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Propostas</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Crie e envie orçamentos profissionais.</p>
        </div>
        <Button className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Proposta
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{proposals.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg sm:rounded-xl text-emerald-500">
              <Check className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Aceitas</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{proposals.filter(p => p.status === 'accepted').length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <Send className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Valor Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">R$ {totalValue.toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar propostas..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {filteredProposals.map((proposal) => {
          const statusConfig = getStatusConfig(proposal.status);
          const client = clients.find(c => c.id === proposal.clientId);
          const StatusIcon = statusConfig.icon;
          
          return (
            <motion.div key={proposal.id} variants={item}>
              <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover h-full flex flex-col">
                <CardContent className="p-4 sm:p-5 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-3 sm:mb-4">
                    <Badge variant="outline" className={cn("text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5 flex items-center gap-1", statusConfig.color)}>
                      <StatusIcon className="w-2.5 h-2.5 sm:w-3 sm:h-3" /> {statusConfig.label}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-6 w-6 sm:h-8 sm:w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity rounded-md sm:rounded-lg">
                          <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl">
                        <DropdownMenuItem><Send className="w-3.5 h-3.5 mr-2" /> Enviar</DropdownMenuItem>
                        <DropdownMenuItem><Download className="w-3.5 h-3.5 mr-2" /> Download</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold font-heading mb-1 sm:mb-2 group-hover:text-primary transition-colors line-clamp-2">{proposal.title}</h3>
                  <p className="text-[10px] sm:text-xs text-muted-foreground mb-3 sm:mb-4">{client?.name || 'Cliente'}</p>

                  <div className="mt-auto pt-3 sm:pt-4 border-t border-border/30 flex items-center justify-between">
                    <div className="flex items-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs text-muted-foreground bg-muted/20 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-md sm:rounded-lg">
                      <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      <span>{new Date(proposal.createdAt).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}</span>
                    </div>
                    <div className="font-mono font-bold text-xs sm:text-sm">
                      <span className="text-emerald-400">R$</span> {proposal.value.toLocaleString('pt-BR')}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </motion.div>
    </div>
  );
}
