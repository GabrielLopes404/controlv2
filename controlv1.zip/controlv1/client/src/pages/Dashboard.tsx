import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { kpis, projects, tasks, invoices } from "@/services/data";
import { ArrowUpRight, ArrowDownRight, Clock, CheckCircle2, FileText, Users, CreditCard, TrendingUp, Activity, DollarSign, Sparkles, Zap, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Progress } from "@/components/ui/progress";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 15 },
  show: { opacity: 1, y: 0 }
};

const revenueData = [
  { name: 'Jan', value: 4000 },
  { name: 'Fev', value: 3000 },
  { name: 'Mar', value: 5000 },
  { name: 'Abr', value: 4780 },
  { name: 'Mai', value: 5890 },
  { name: 'Jun', value: 6390 },
  { name: 'Jul', value: 7490 },
];

const kpiIcons = [DollarSign, Users, Clock, FileText];

export default function Dashboard() {
  const pendingTasks = tasks.filter(t => t.status !== 'done').length;
  
  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4 sm:space-y-6"
    >
      <motion.div variants={item} className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Dashboard</h1>
            <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-primary animate-pulse" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Bem-vindo de volta! Aqui está o resumo do seu negócio.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-9 sm:h-10 text-xs sm:text-sm border-border/60 hover:border-primary hover:bg-primary/5 transition-all rounded-xl">
            <Activity className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Relatório
          </Button>
          <Button size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
            <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Projeto
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4">
        {kpis.map((kpi, i) => {
          const Icon = kpiIcons[i];
          return (
            <motion.div key={i} variants={item}>
              <Card className={cn(
                "relative overflow-hidden border-border/40 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-xl transition-all duration-300 group hover:border-border/60 card-hover rounded-xl sm:rounded-2xl",
              )}>
                <div className={cn(
                  "absolute -top-6 -right-6 sm:-top-8 sm:-right-8 w-16 h-16 sm:w-24 sm:h-24 rounded-full opacity-10 blur-2xl transition-opacity group-hover:opacity-20",
                  i === 0 ? "bg-primary" : i === 1 ? "bg-blue-500" : i === 2 ? "bg-purple-500" : "bg-amber-500"
                )} />
                <CardContent className="p-3 sm:p-4 lg:p-5">
                  <div className="flex items-start justify-between mb-2 sm:mb-3">
                    <div className={cn(
                      "p-1.5 sm:p-2 lg:p-2.5 rounded-lg sm:rounded-xl transition-all",
                      i === 0 ? "bg-primary/10 text-primary" : 
                      i === 1 ? "bg-blue-500/10 text-blue-500" :
                      i === 2 ? "bg-purple-500/10 text-purple-500" :
                      "bg-amber-500/10 text-amber-500"
                    )}>
                      <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />
                    </div>
                    <Badge variant="outline" className={cn(
                      "border-0 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5 py-0.5",
                      kpi.trend === "up" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                    )}>
                      <span className="flex items-center gap-0.5">
                        {kpi.trend === "up" ? <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3" /> : <ArrowDownRight className="w-2.5 h-2.5 sm:w-3 sm:h-3" />}
                        {Math.abs(kpi.change)}%
                      </span>
                    </Badge>
                  </div>
                  
                  <div className="space-y-0.5">
                    <p className="text-[9px] sm:text-[10px] lg:text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{kpi.label}</p>
                    <h3 className="text-base sm:text-lg lg:text-2xl font-bold font-heading tracking-tight">{kpi.value}</h3>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 sm:gap-4 lg:gap-6">
        <motion.div variants={item} className="xl:col-span-2 space-y-3 sm:space-y-4 lg:space-y-6">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardHeader className="pb-2 px-3 sm:px-4 lg:px-6 pt-3 sm:pt-4 lg:pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Receita Mensal</CardTitle>
                  <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">Últimos 7 meses</p>
                </div>
                <Badge className="bg-emerald-500/15 text-emerald-400 border-0 text-[9px] sm:text-[10px]">
                  <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> +24%
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="h-[180px] sm:h-[200px] lg:h-[240px] px-1 sm:px-2 lg:px-4 pb-3 sm:pb-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                      <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))', 
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                    formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Receita']}
                  />
                  <Area type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 lg:px-6 pt-3 sm:pt-4 lg:pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg">
                    <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
                  </div>
                  <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Projetos Ativos</CardTitle>
                </div>
                <Button variant="ghost" size="sm" className="text-[10px] sm:text-xs text-primary hover:bg-primary/10 -mr-2 h-7 sm:h-8 rounded-lg">
                  Ver todos <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="px-0 pb-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm">
                  <thead>
                    <tr className="border-y border-border/40 bg-muted/20">
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Projeto</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Status</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Prazo</th>
                      <th className="px-3 sm:px-4 lg:px-6 py-2 sm:py-3 text-right text-[10px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Progresso</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/30">
                    {projects.slice(0, 4).map((project) => (
                      <tr key={project.id} className="hover:bg-muted/10 transition-colors group cursor-pointer">
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5">
                          <div>
                            <p className="font-semibold text-xs sm:text-sm group-hover:text-primary transition-colors line-clamp-1">{project.title}</p>
                            <p className="text-[10px] sm:text-[11px] text-muted-foreground mt-0.5 hidden xs:block">TechFlow Inc.</p>
                          </div>
                        </td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 hidden sm:table-cell">
                          <Badge variant="outline" className={cn(
                            "text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5",
                            project.status === "in_progress" && "bg-blue-500/15 text-blue-400",
                            project.status === "completed" && "bg-emerald-500/15 text-emerald-400",
                            project.status === "proposal" && "bg-amber-500/15 text-amber-400",
                          )}>
                            {project.status === "in_progress" ? "Andamento" : project.status === "completed" ? "Concluído" : "Proposta"}
                          </Badge>
                        </td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5 hidden lg:table-cell">
                          <span className="text-xs sm:text-sm text-muted-foreground">{new Date(project.deadline).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}</span>
                        </td>
                        <td className="px-3 sm:px-4 lg:px-6 py-2.5 sm:py-3.5">
                          <div className="flex items-center justify-end gap-2 sm:gap-3">
                            <div className="w-14 sm:w-20 lg:w-24">
                              <Progress value={project.progress} className="h-1 sm:h-1.5" />
                            </div>
                            <span className="text-[10px] sm:text-xs font-bold w-7 sm:w-8 text-right">{project.progress}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="space-y-3 sm:space-y-4 lg:space-y-6">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
            <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 lg:px-5 pt-3 sm:pt-4 lg:pt-5">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm sm:text-base font-heading flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" /> Tarefas Hoje
                </CardTitle>
                <Badge className="bg-primary/20 text-primary border-0 text-[10px] sm:text-xs font-bold">{pendingTasks}</Badge>
              </div>
            </CardHeader>
            <CardContent className="px-2 sm:px-3 pb-3">
              <div className="space-y-1">
                {tasks.slice(0, 5).map((task) => (
                  <div key={task.id} className={cn(
                    "flex items-start gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg sm:rounded-xl hover:bg-muted/30 transition-all cursor-pointer group"
                  )}>
                    <div className="mt-0.5 shrink-0">
                      <div className={cn(
                        "w-4 h-4 sm:w-5 sm:h-5 rounded-md border-2 flex items-center justify-center transition-all",
                        task.status === "done" 
                          ? "bg-primary border-primary" 
                          : "border-muted-foreground/30 group-hover:border-primary"
                      )}>
                        {task.status === "done" && <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-white" />}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        "text-xs sm:text-sm font-medium leading-tight group-hover:text-primary transition-colors line-clamp-1",
                        task.status === "done" && "text-muted-foreground line-through"
                      )}>
                        {task.title}
                      </p>
                      <div className="flex items-center gap-1.5 sm:gap-2 mt-1 sm:mt-1.5">
                        <Badge variant="outline" className={cn(
                          "text-[8px] sm:text-[9px] h-3.5 sm:h-4 px-1 sm:px-1.5 border-0 font-semibold",
                          task.priority === "high" && "bg-red-500/15 text-red-400",
                          task.priority === "medium" && "bg-amber-500/15 text-amber-400",
                          task.priority === "low" && "bg-blue-500/15 text-blue-400",
                        )}>
                          {task.priority === "high" ? "Alta" : task.priority === "medium" ? "Média" : "Baixa"}
                        </Badge>
                        <span className="text-[9px] sm:text-[10px] text-muted-foreground">
                          {new Date(task.dueDate).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
            <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 lg:px-5 pt-3 sm:pt-4 lg:pt-5">
              <CardTitle className="text-sm sm:text-base font-heading flex items-center gap-2">
                <CreditCard className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-500" /> Últimas Receitas
              </CardTitle>
            </CardHeader>
            <CardContent className="px-2 sm:px-3 lg:px-4 pb-3 sm:pb-4 space-y-1.5 sm:space-y-2">
              {invoices.filter(i => i.status === 'paid').slice(0, 3).map((inv) => (
                <div key={inv.id} className="flex items-center justify-between p-2 sm:p-3 rounded-lg sm:rounded-xl bg-emerald-500/5 border border-emerald-500/10 hover:border-emerald-500/20 transition-colors">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-xs sm:text-sm truncate">{inv.description}</p>
                    <p className="text-[10px] sm:text-[11px] text-muted-foreground mt-0.5">{new Date(inv.date).toLocaleDateString('pt-BR')}</p>
                  </div>
                  <p className="font-mono font-bold text-xs sm:text-sm text-emerald-400 shrink-0 ml-2">+R$ {inv.amount.toLocaleString('pt-BR')}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            {[
              { icon: FileText, label: "Proposta", color: "text-blue-400 bg-blue-500/10" },
              { icon: Users, label: "Cliente", color: "text-emerald-400 bg-emerald-500/10" },
              { icon: CreditCard, label: "Fatura", color: "text-purple-400 bg-purple-500/10" },
              { icon: Clock, label: "Timer", color: "text-amber-400 bg-amber-500/10" }
            ].map((action, i) => (
              <Button 
                key={i}
                variant="outline" 
                className="h-16 sm:h-20 flex flex-col gap-1.5 sm:gap-2 border-border/40 bg-card/40 hover:bg-muted/30 hover:border-primary/30 transition-all rounded-lg sm:rounded-xl group"
              >
                <div className={cn("p-1.5 sm:p-2 rounded-lg transition-all", action.color)}>
                  <action.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <span className="text-[10px] sm:text-[11px] font-semibold text-muted-foreground group-hover:text-foreground">{action.label}</span>
              </Button>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
