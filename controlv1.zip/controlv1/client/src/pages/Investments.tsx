import { investments } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, Plus, Wallet, ArrowUpRight, Sparkles, ArrowDownRight } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  PieChart as RePieChart, Pie, Cell, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid
} from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const COLORS = ['#FF00AA', '#3b82f6', '#10b981', '#eab308'];

const portfolioHistory = [
  { month: 'Jan', value: 10000 },
  { month: 'Fev', value: 11500 },
  { month: 'Mar', value: 11200 },
  { month: 'Abr', value: 13800 },
  { month: 'Mai', value: 15100 },
  { month: 'Jun', value: 16500 },
];

export default function Investments() {
  const totalInvested = investments.reduce((acc, curr) => acc + curr.currentTotal, 0);
  const totalProfit = investments.reduce((acc, curr) => acc + curr.profit, 0);
  const totalProfitPercent = (totalProfit / (totalInvested - totalProfit)) * 100;

  const allocationData = investments.map(inv => ({
    name: inv.type,
    value: inv.currentTotal
  }));

  const groupedAllocation = allocationData.reduce((acc: any, curr) => {
    const existing = acc.find((a: any) => a.name === curr.name);
    if (existing) {
      existing.value += curr.value;
    } else {
      acc.push({ ...curr });
    }
    return acc;
  }, []);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Investimentos</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Acompanhe a evolução do seu patrimônio.</p>
        </div>
        <Button className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white shadow-lg shadow-emerald-500/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Aporte
        </Button>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4"
      >
        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-emerald-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-emerald-500/20 rounded-lg sm:rounded-xl text-emerald-400">
                  <Wallet className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <Badge variant="outline" className="border-0 bg-emerald-500/15 text-emerald-400 text-[9px] sm:text-[10px] font-bold">
                  <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> +{totalProfitPercent.toFixed(1)}%
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Patrimônio Total</p>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5">R$ {totalInvested.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-blue-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-blue-500/20 rounded-lg sm:rounded-xl text-blue-400">
                  <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Lucro Total</p>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5 text-emerald-400">+R$ {totalProfit.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-primary/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-primary/20 rounded-lg sm:rounded-xl text-primary">
                  <DollarSign className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Rendimento Mensal</p>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5">+2.3%</h3>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6">
        <motion.div variants={item} className="lg:col-span-2">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden h-full">
            <CardHeader className="pb-2 px-4 sm:px-6 pt-4 sm:pt-6">
              <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Evolução do Patrimônio</CardTitle>
            </CardHeader>
            <CardContent className="h-[200px] sm:h-[250px] px-2 sm:px-4 pb-4 sm:pb-6">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={portfolioHistory} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorPortfolio" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))', 
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                    formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Total']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#10b981" fillOpacity={1} fill="url(#colorPortfolio)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden h-full">
            <CardHeader className="pb-2 px-4 sm:px-6 pt-4 sm:pt-6">
              <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Alocação</CardTitle>
            </CardHeader>
            <CardContent className="h-[180px] sm:h-[200px] flex items-center justify-center px-4 sm:px-6 pb-4 sm:pb-6">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={groupedAllocation}
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {groupedAllocation.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, '']}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))', 
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>
            </CardContent>
            <div className="px-4 sm:px-6 pb-4 sm:pb-6">
              <div className="grid grid-cols-2 gap-2">
                {groupedAllocation.map((item: any, i: number) => (
                  <div key={i} className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs">
                    <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                    <span className="text-muted-foreground truncate">{item.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
        <CardHeader className="pb-2 sm:pb-3 px-4 sm:px-6 pt-4 sm:pt-6">
          <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Seus Investimentos</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-border/40 bg-muted/20">
                  <th className="px-4 sm:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Ativo</th>
                  <th className="px-4 sm:px-6 py-2 sm:py-3 text-left text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Tipo</th>
                  <th className="px-4 sm:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Total</th>
                  <th className="px-4 sm:px-6 py-2 sm:py-3 text-right text-[9px] sm:text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Lucro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {investments.map((inv) => (
                  <tr key={inv.id} className="hover:bg-muted/10 transition-colors">
                    <td className="px-4 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-xs sm:text-sm">{inv.name}</td>
                    <td className="px-4 sm:px-6 py-2.5 sm:py-3.5 hidden sm:table-cell">
                      <Badge variant="secondary" className="text-[9px] sm:text-[10px] bg-muted/50">{inv.type}</Badge>
                    </td>
                    <td className="px-4 sm:px-6 py-2.5 sm:py-3.5 text-right font-mono font-bold text-xs sm:text-sm">R$ {inv.currentTotal.toLocaleString('pt-BR')}</td>
                    <td className="px-4 sm:px-6 py-2.5 sm:py-3.5 text-right">
                      <span className={cn("font-mono font-bold text-xs sm:text-sm flex items-center justify-end gap-0.5", inv.profit >= 0 ? "text-emerald-400" : "text-red-400")}>
                        {inv.profit >= 0 ? <ArrowUpRight className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> : <ArrowDownRight className="w-3 h-3 sm:w-3.5 sm:h-3.5" />}
                        R$ {Math.abs(inv.profit).toLocaleString('pt-BR')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
