# Lopes Control - CRM for Freelancers

## Overview

Lopes Control is a comprehensive CRM (Customer Relationship Management) application designed specifically for freelance designers and creative professionals. The platform provides end-to-end management of clients, projects, tasks, finances, proposals, investments, and goals.

The application is built as a full-stack TypeScript project with a React frontend and Express backend, following a monorepo structure with shared code between client and server.

**Target User:** Solo freelance designers who need to manage their entire business workflow in one place.

**Core Features:**
- Client management with revenue tracking
- Project lifecycle management with progress tracking
- Task management with drag-and-drop Kanban boards
- Financial tracking (invoices, expenses, cash flow)
- Proposal creation and management
- Personal investment portfolio tracking
- Goal setting and progress monitoring
- Real-time chat interface
- Calendar integration
- Client portal for external access
- Template library for documents

## User Preferences

- Preferred communication style: Simple, everyday language
- Preferred language: Portuguese (Brazil)

## Recent Changes (December 2025)

- Complete UI optimization for all 15+ pages with mobile-first responsive design
- Implemented consistent breakpoints: sm(640px), md(768px), lg(1024px), xl(1280px)
- Added glassmorphism effects with backdrop-blur and gradient accents
- Framer Motion animations with stagger effects on all pages
- Custom hidden scrollbars for clean mobile experience
- Touch-friendly button sizes and spacing
- Fixed ClientPortal routing regression (useParams restored)

## System Architecture

### Frontend Architecture
- **Framework:** React 18 with TypeScript
- **Routing:** Wouter (lightweight React router)
- **State Management:** TanStack React Query for server state
- **UI Components:** shadcn/ui component library built on Radix UI primitives
- **Styling:** Tailwind CSS v4 with CSS variables for theming
- **Animations:** Framer Motion for page transitions and micro-interactions
- **Charts:** Recharts for data visualization
- **Drag & Drop:** @dnd-kit for sortable task lists
- **Build Tool:** Vite

### Backend Architecture
- **Runtime:** Node.js with Express
- **Language:** TypeScript compiled with tsx
- **API Pattern:** RESTful API with `/api` prefix
- **Storage Interface:** Abstract `IStorage` interface allowing swappable implementations (currently in-memory, designed for PostgreSQL)

### Design Patterns
- **Monorepo Structure:** Shared types and schemas between frontend and backend via `@shared` alias
- **Component Composition:** Layout wrapper pattern with sidebar navigation
- **Theme System:** Dark/light mode with CSS custom properties and ThemeProvider context
- **Mock Data:** Currently uses static mock data in `client/src/services/data.ts` for prototyping

### Directory Structure
```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/  # UI components (layout, ui library)
│   │   ├── pages/       # Route page components
│   │   ├── services/    # Data services and mock data
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route definitions
│   └── storage.ts    # Data storage abstraction
├── shared/           # Shared code between client/server
│   └── schema.ts     # Drizzle ORM schema and Zod validation
└── migrations/       # Database migrations (Drizzle)
```

## External Dependencies

### Database
- **ORM:** Drizzle ORM configured for PostgreSQL
- **Schema Location:** `shared/schema.ts`
- **Migrations:** Managed via `drizzle-kit push`
- **Connection:** Requires `DATABASE_URL` environment variable

### UI Component Libraries
- **Radix UI:** Complete primitive library for accessible components
- **shadcn/ui:** Pre-styled component system (new-york style variant)
- **Lucide React:** Icon library

### Third-Party Services (Planned/Configured)
- **Google Calendar:** Sync capability indicated in UI
- **Session Management:** `connect-pg-simple` for PostgreSQL session storage
- **Email:** Nodemailer configured in build dependencies

### Development Tools
- **Replit Plugins:** Cartographer, dev banner, runtime error overlay
- **Meta Images:** Custom Vite plugin for OpenGraph image handling

### Branding Configuration
- **Primary Color:** #FF00AA (magenta/pink)
- **Color Scheme:** Dark mode default
- **Fonts:** Rajdhani (headings), Inter (body)
- **Language:** Portuguese (Brazil)